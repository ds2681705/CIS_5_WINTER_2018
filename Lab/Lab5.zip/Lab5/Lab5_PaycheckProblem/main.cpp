//Dakoda Stemen

//Wait on it, sometimes it takes a little...
#include <iostream>

using std::cout;
using std::cin;
using std::fixed;

#include <iomanip>

using std::setprecision;

//main thing
int main()
{
int total; 
int hrs; 
int rte; 
int ovr; 

total = 0;
ovr = 0;

cout << "Enter hours worked (1 to end):";
cin >> hrs;

while ( hrs != -1 ) 
{
cout << "\nEnter hourly rate of the worker ($10 for Lab 5):";
cin >> rte;
if ( hrs > 40 );
ovr = ( rte * .5 * hrs );
total = ( hrs * rte + ovr );
cout << "\nSalary is $" << setprecision ( 2 ) << fixed << total;
cout << " & OT Hours = " << (hrs - 40);

cout << "\nEnter hours worked (1 to end):";
cin >> hrs;

if ( hrs < 0 );
break;
}

return 0;

}