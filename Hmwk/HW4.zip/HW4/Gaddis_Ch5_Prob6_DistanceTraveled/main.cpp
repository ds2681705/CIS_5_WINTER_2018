//Dakoda Stemen - 22 Jan 2018

#include <iostream>

using namespace std;

int main()
{
    
    float d;
    float s;
    int t;
    
    cout << "What is the speed of the vehicle (mph)? ";
    cin >> s;
    
    while (s <= 0)
    {
        cout << "MUST BE GREATER THAN 0! Enter again. . .";
                cin >> s; 
    }
    
    cout << "How many hours has it traveled? ";
    cin >> t;
    
    while (t < 1)
    {
        cout << "MUST BE GREATER THAN 1! Enter again. . .";
                cin >> t; 
    }
    
   cout << "\nHour\tDistance Traveled:\n"; 
   cout << "-----  -------------------\n"; 
            
   for (int i = 1; i <= t; i++)
           { 
               d = s * i;
               cout << i << "\t\t" << d << endl;
           }
    
    
    return 0;
}