//Dakoda Stemen - 22 Jan 2018

#include <iostream>

using namespace std;

int main()
{
    int nums;
    int sum =0;
    
    //Enter 50 in here for the HW (should equal 1275 if it works through 50... & 5050 for 100...    
    cout << "Enter total amount of number(s) you wish to find the sum of. \n";
    cin >> nums;
    for (int i=1; i <= nums; i++)
    {
        sum += i;
    }
    cout << "total is " << sum;
    
    return 0;
}
