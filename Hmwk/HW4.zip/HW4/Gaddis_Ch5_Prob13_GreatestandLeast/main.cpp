//Dakoda Stemen - 22 Jan 2018

#include <iostream>

using namespace std;

int main()
{
    //they can all be int's
    int number = 0;
    int high;
    int low;
    int counter = 0;
    
    while (number != -99)
    {
        cout << "Please enter whole numbers. Enter -99 to Calculate: \n";
        cin >> number;
   
        if (counter == 0)
            {
                high = number;
                low = number;
         }
         else
            {
                if (number > high && number != -99)
                    high = number;
                else if (number < low && number != -99)
                    low = number;
             }
        counter++;
    }
    //print it
    cout << "The highest number you entered was: \n" << high << endl;
    cout << "The smallest number you entered was: \n" << low << endl;
    
    return 0;
}