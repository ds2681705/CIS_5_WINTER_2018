//Dakoda Stemen - 23 Jan 2018

#include <iostream>
using namespace std;

int main()
{
	char letter;
        
        //The first 32 characters are control charecters... So it technically starts with the "space" key, and as you can see it definitely stops it after 16 characters. 
        
	cout << " This program will display charecters 0-127 of the ASCII codes. \n";

	letter = 0;

        for(int count = 0; count <= 127; count++)
	{
		if (count % 16 ==0)
           		cout << endl; 
		   
		        cout << letter << "  ";
			letter++;
		
	}
	
	return 0;
}