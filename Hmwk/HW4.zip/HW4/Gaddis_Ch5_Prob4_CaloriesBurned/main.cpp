//Dakoda Stemen - 22 Jan 2018

#include <iostream>

using namespace std;

int main()
{
    //use floats
    float calorieBurn;
    float CPM = 3.9f;
    
    for (int i = 10; i <= 30; i += 5)
    {
        calorieBurn = i * CPM;
        cout << "In " << i << " minutes you burned through " << calorieBurn << " cals." << endl;
    }
     
    return 0;
}