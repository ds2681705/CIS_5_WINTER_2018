//Dakoda Stemen - 22 Jan 2018

#include <iostream>

using namespace std;

int main()
{
    //couple of constants
    const float incr = 0.04;
    const int yrs = 6;
    float membersh = 2500;
    
    for (int i = 1; i <= yrs; i++)
    {
        membersh = membersh + (membersh * incr);
        cout << "Year " << i << " charges changed to: $" << membersh << endl;
    }
   
    return 0;
}