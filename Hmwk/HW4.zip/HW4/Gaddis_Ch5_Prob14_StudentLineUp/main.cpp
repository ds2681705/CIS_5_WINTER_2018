//Dakoda Stemen - 22 Jan 2018

#include <iostream>


using namespace std;

int main()
{
    //use strings for fun since it's names
   int numStudents = 0;
   string studentName;
   string firstStudent;
   string lastStudent;
   
   while (numStudents < 1 || numStudents > 25)
   {
       cout << "Please enter number of students. Must be a number between 1 and 25 \n";
       cin >> numStudents;
   }
   
   for (int i = 1; i <= numStudents; i++)
   {
       cout << "Please enter name of student #" << i << endl;
       cin >> studentName;
       
       if (i == 1)
       {
           firstStudent = studentName;
           lastStudent = studentName;       
       }
       
       else 
       {
           if (studentName < firstStudent)
               firstStudent = studentName;
           else if (studentName > lastStudent)
               lastStudent = studentName;
       }
   }
   //print 
   cout << "First Student is " << firstStudent << endl;
   cout << "Last Student is " << lastStudent << endl;
   
   return 0;
}