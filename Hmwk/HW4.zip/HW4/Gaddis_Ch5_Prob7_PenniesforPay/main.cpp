//Dakoda Stemen - 22 Jan 2018

#include <iostream>

using namespace std;

int main()
{
    int numDays = 1;
    double money = 1.0;
    double total = 0.0;
    double dayPay = 0.0;
    
    cout << "Enter how manys days: \n";
    cin >> numDays;
    
    while (numDays < 1)
    {
        cout << "DAYS MUST BE MORE THAN 1... Enter again...";
        cin >> numDays;
    }
    
    for (int i = 1; i <= numDays; i++)
    {
        dayPay = money / 100;
        cout << "Day " << i << " you earned $" << dayPay << "\n";
        total += dayPay;
        money *= 2;
    }
    cout << "Total earning are $" << total << endl;
    
    return 0;
 } 