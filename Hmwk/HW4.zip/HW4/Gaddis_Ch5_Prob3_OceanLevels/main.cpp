//Dakoda Stemen - 22 Jan 2018

#include <iostream>

using namespace std;

int main()
{
    //int & dub
    double level = 0;
    int years = 25;
    
    for (int i = 1; i <= years; i++)
    {
        level += 1.5;
        cout << "Year " << i << ": " << level << "mm\n";
    }
        
    
    return 0;
}