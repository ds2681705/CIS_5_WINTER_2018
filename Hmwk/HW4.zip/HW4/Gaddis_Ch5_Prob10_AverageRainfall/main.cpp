//Dakoda Stemen

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    //have a const int
    int numYears = 0;
    const int Month = 12;
    float totalRainfall = 0.0f;
    float rainfall = 0.0f;
    float avgRainfall = 0.0f;

    cout << "Enter number of years: " << endl;
    cin >> numYears;
    
    while (numYears < 1)
    {
        cout << "MUST BE GREATER THAN 1! Enter again...";
        cin >> numYears;
    }
    
    for (int i = 1; i <= numYears; i++)
    {
        for (int months = 1; months <= Month; months++)
        {
            cout << "Please enter the ranfall during " << months << " month: ";
            cin >> rainfall;
            
            while (rainfall < 0)
            {
                cout << "MUST BE GREATER THAN 0! Enter again...";
                cin >> rainfall;
            }
            
            totalRainfall += rainfall;
        }
    } 
    
    //print it all out
    cout << "\nNumber of months: " << numYears * Month << endl;
    cout << "Total rainfall: " << setprecision(2) << fixed << totalRainfall << " inches." << endl;
    cout << "Average rainfall: " << setprecision(2) << fixed << totalRainfall / (numYears * Month) << " inches." << endl;
    
    return 0;
}