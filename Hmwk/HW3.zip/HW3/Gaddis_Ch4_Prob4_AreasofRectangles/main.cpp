//Dakoda Stemen

#include<iostream>

using namespace std;

int main () 
{
    float side1A, side2A, side1B, side2B;
    double area1;
    double area2;
    
    cout << "Enter width of a Rectangle 1: ";
    cin >> side1A;
    
    cout << "Enter height of Rectangle 1: ";
    cin >> side2A;
    
    cout << "Enter width of a Rectangle 2: ";
    cin >> side1B;
    
    cout << "Enter height of Rectangle 2: ";
    cin >> side2B;
    
    area1 = side1A * side2A;
    area2 = side1B * side2B;
    
    if (area1 > area2)
    {
        cout << area1 << endl;
    }
    else 
    {
        cout << "Biggest Rectangle, with Area of " << area2 << endl;
    }
 return 0;
}