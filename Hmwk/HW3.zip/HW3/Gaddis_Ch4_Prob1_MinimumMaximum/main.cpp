//Dakoda Stemen

#include <iostream>

int main()
{
    using namespace std;
    
//3 instead of 2 for fun    
    int a, b, c; 
    
    cout << "Please enter a number...\n";
    cin >> a;
    cout << "And another...\n";
    cin >> b;
    cout << "And last one...\n";
    cin >> c;
    cout << "Thank you!\n";
    
    if (a > b)
    {
          if (a > c)
          cout << a << endl;
          }
    if (b > c)
    {
          if (b > a)
          cout << b << endl;
          }
    if (c > a)
    {
          if (c > b)
          cout << c << endl;
          }
    
    char response;
    cin >> response;
    
    endl;
    
    return 0;
}