//Dakoda Stemen

#include <iostream>
using namespace std;
int main()
{
 int day;
 int month;
 int year;
 
 
 cout << "Enter the year" << endl;
 cin >> year;
 cout << "Enter the day" << endl;
 cin >> day;
 cout << "Enter the month" << endl;
 cin >> month;
 
 if(month * day == year)
 {
 cout << "It is a Magic Year!" << endl;
 }
 else 
 {
 cout <<"It is not a Magic Year!" << endl;
 }
 }