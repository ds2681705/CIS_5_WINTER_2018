//Dakoda Stemen

#include <iostream>

using namespace std;


int main()
{
double feet;
double inches;
double height;
double weight;
double bmi;

cout << "== BMI Calculator ==" << endl;
cout << "Step 1: Enter height" << endl;

cout << "Feet:" << endl;
cin >> feet;

cout << "Inches:" << endl;
cin >> inches;

cout << "step 2: Enter weight" << endl;
cout << "Pounds:" << endl;
cin >> weight;

height = (feet * 12) + inches;
bmi = (weight * 703) / (height * height);

if (bmi < 18.5)
{
    cout << "You're underweight...";
}
    if (bmi > 25)
    {
        cout << "You're overweight...";
        
    }
    else 
        {
        cout << "You're normal!";
    }
    
    return 0;
}