//Dakoda Stemen

#include<iostream>
#include<iomanip>
#include<string>

using namespace std;

int main()
{
 double distance, time;
 int choice;

 const double CARBONDIOXIDE = 258.0,
         AIR = 331.5,
    HELIUM = 972.0,
    HYDROGEN = 1270.0;

 const int CARBONDIOXIDE_CHOICE = 1,
    AIR_CHOICE = 2,
    HELIUM_CHOICE = 3,
    HYDROGEN_CHOICE = 4,
    QUIT_CHOICE = 5;

 //menu things and choices
 cout << "\t\tThe Speed of Sound in Gases: \n\n"
  << "1.  Carbon Dioxide \n"
  << "2.  Air \n"
  << "3.  Helium \n"
  << "4.  Hydrogen \n"
  << "5.  Quit the Program \n\n"
  << "Enter your choice: ";
 cin >> choice;

 cout << fixed << showpoint << setprecision(4);

 switch(choice)
 {
 case CARBONDIOXIDE_CHOICE:
 cout << "Enter the number of seconds (from 0 - 30) ";
 cin >> time;
 
 if(time < 0 || time > 30)
 {
 cout << "Time has to be between 0 - 30 seconds!! \n\n"
      << "Enter the time again: ";
 cin >> time;
 }
 distance = time * CARBONDIOXIDE;
 cout << "The source of the sound is " << distance << " meters away. \n\n";
 break;

 case AIR_CHOICE:
 cout << "Enter the number of seconds (from 0 - 30) ";
 cin >> time;
 
 if(time < 0 || time > 30)
 {
 cout << "Time has to be between 0 - 30 seconds!! \n\n"
      << "Enter the time again: ";
 cin >> time;
 }
 distance = time * AIR;
 cout << "The source of the sound is " << distance << " meters away. \n\n";
 break;

 case HELIUM_CHOICE:
 cout << "Enter the number of seconds (from 0 - 30) ";
 cin >> time;
 
 if(time < 0 || time > 30)
 {
 cout << "Time has to be between 0 - 30 seconds!! \n\n"
      << "Enter the time again: ";
 cin >> time;
 }
 distance = time * HELIUM;
 cout << "The source of the sound is " << distance << " meters away. \n\n";
 break;

 case HYDROGEN_CHOICE:
 cout << "Enter the number of seconds (from 0 - 30) ";
 cin >> time;
 
 if(time < 0 || time > 30)
 {
 cout << "Time has to be between 0 - 30 seconds!! \n\n"
      << "Enter the time again: ";
 cin >> time;
 }
 distance = time * HYDROGEN;
 cout << "The source of the sound is " << distance << " meters away. \n\n";
 break;

 case QUIT_CHOICE:
 cout << "The Program is ending... \n\n";
 break;

 default:
 cout << "The valid choices are 1 - 5. \n"
  << "Run the program again. \n\n";

 }

 return 0;
}