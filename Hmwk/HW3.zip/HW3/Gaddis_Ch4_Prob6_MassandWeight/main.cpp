//Dakoda Stemen

#include <iostream>

using namespace std;

int main()
{
 int mass;
 float w;
 cout << "Enter the mass of body: " << endl;
 cin >> mass;
 
 
 w = mass * 9.8;
 
 
 if(w >= 1000)
 {
 cout << "It's getting too heavy: " << w <<endl;
 }
 else if (w <= 10)
 {
 cout <<"It's getting too light: " << w << endl;
 }
 
 
 return 0;
}