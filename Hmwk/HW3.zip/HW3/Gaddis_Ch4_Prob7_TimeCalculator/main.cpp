//Dakoda Stemen

#include <iostream>
using namespace std;
int main()
{
 float m;
 float s;
 float d;
 float h;
 float y;
 
 
 cout << "Enter the number of seconds " << endl;
 cin >> s ;
 
 if (s >= 31104000)
 //equate
 {
 cout << "The seconds you entered are " << s/31104000 << " Year(s)" << endl; 
 }
 else if (s >= 2592000)
 {
 cout << "The seconds you entered are " << s/2592000<< " Month(s)" << endl;
 }
 else if (s >= 86400)
 {
 cout << "The seconds you entered are " << s/86400 << " Day(s)" << endl;
 }
 else if (s >= 3600)
 {
 cout << "The seconds you entered are " << s/3600 << " Hour(s)" << endl;
 }
 else if (s >= 60)
 {
 cout << "The seconds you entered are " << s/60 << " Minute(s)" << endl;
 
 }
 if(s < 60 && s > 0)
 {
 cout << "The seconds you entered = " << s <<endl;
 }
 
 
 }