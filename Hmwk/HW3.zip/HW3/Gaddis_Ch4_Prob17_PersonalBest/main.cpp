//Dakoda Stemen

#include <iostream>
using namespace std;

int main ()
{
    cout << "Enter your name: " << endl;
    int name;
    cin >> name;
    
    cout << "Enter your 3 best scores..." << endl;
    
       
    
    cout << "Score 1: " << endl;
    int score1;
    cin >> score1;
    
    cout << "Score 2: " << endl;
    int score2;
    cin >> score2;
    
    cout << "Score 3: " << endl;
    int score3;
    cin >> score3;
    
   if (score1 > score2,score3)
   {
       cout << "Personal Best: " << score1 << endl;
   }
    
   else if (score2 > score1,score3)
   {
       cout << "Personal Best: " << score2 << endl;
   }
    
   else if (score3 > score1,score2)
   {
       cout << "Personal Best: " << score3 << endl;
   }
    
    
    return 0;
}