//Dakoda Stemen
#include <iostream>


using namespace std;


int main()

{
	int blue;
	int green;
	int red;
	

	cout << "There are three primary colors: blue, green and red. " << endl;
	cout << "Pick two primary colors to see what new color is made: " << endl;
	


	{

		cin >> blue, green, red;
		if (blue && green)
		{
			cout << "The secondary color made is cyan " << endl;
		}
		else if (blue && red)
		{
		
			cout << "The secondary color is magenta " << endl;
		}
		else if (green && red)
		{
			cout << "The secondary color made is yellow.  " << endl;
		}
	}

	return 0;
}